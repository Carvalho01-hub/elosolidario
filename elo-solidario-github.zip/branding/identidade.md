# Identidade da Plataforma – Elo Solidário

**Propósito:** Conectar quem quer ajudar a quem precisa.

**Valores:** Transparência, Impacto, Confiança, Inclusão.

**Tom de voz:** Humano, claro, confiável.

**Cores:** Verde (esperança), Azul (confiança).
