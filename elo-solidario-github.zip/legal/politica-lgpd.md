# Política de Privacidade (LGPD)

Coletamos apenas dados necessários, com consentimento, garantindo segurança e direitos do titular.
