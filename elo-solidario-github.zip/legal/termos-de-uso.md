# Termos de Uso – Elo Solidário

O usuário concorda com as regras de uso da plataforma, finalidade social e veracidade das informações.
