# Elo Solidário

Plataforma de doações com impacto social, transparência e benefícios fiscais.
