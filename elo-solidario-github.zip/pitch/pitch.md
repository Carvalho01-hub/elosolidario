# Pitch – Elo Solidário

Elo Solidário é uma plataforma que conecta doadores e ONGs, permitindo doações via Pix com dedução fiscal e acompanhamento de impacto social.

**Problema:** Falta de confiança e informação sobre doações.
**Solução:** Tecnologia + transparência + IA fiscal.
**Modelo:** Parcerias, SaaS para ONGs, patrocínios.
